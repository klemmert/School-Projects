/*
 * This is to show an example of Inheritance as well as Encapsulation.
 *
 * Inheritance: Person is the parent class while Trainer and GymLeader are its child classes. I am reusing all the fields from the Person class in
 * the child class as well as implementing their own unique parts.
 *
 * Encapsulation: I am keeping "sensitive" data hidden from users. I am using private variabes and providing public setters
 * and getters to access and update my private variables to the objects.
 */

#pragma once
#include <iostream>
#include <string>
#include <vector>

using namespace std;

class Person
{
private:
	string name;
	vector <string> pokemon;
public:
	Person() {

	}

	Person(string pName, vector <string> pPokemon) {
		name = pName;
		pokemon = pPokemon;
	}

	string getName() {
		return name;
	}
	vector <string> getPokemon() {
		return pokemon;
	}
	void setName(string pName) {
		name = pName;
	}
	void setPokemon(vector <string> pPokemon) {
		pokemon = pPokemon;
	}
};

//trainer class is derived from person class
class Trainer : public Person {
private:
	int numOfBadges;
	vector <string> badges;
public:
	Trainer() {

	}

	Trainer(int tNum, vector<string> tBadges) {
		numOfBadges = tNum;
		badges = tBadges;
	}

	int getNumOfBadges() {
		return numOfBadges;
	}
	vector <string> getBadges() {
		return badges;
	}
	void setNumOfBadges(int tNum) {
		numOfBadges = tNum;
	}
	void setBadges(vector <string> tBadges) {
		badges = tBadges;
	}
};

//gym leader class is derived from person class
class GymLeader : public Person {
private:
	string badge;
public:
	GymLeader() {

	}

	GymLeader(string gBadge) {
		badge = gBadge;
	}

	string getBadge()
	{
		return badge;
	}

	void setBadge(string gBadge)
	{
		badge = gBadge;
	}
};

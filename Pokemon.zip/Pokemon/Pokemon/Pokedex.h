﻿/*
 * This is to show a small example of Polymorphism as well as Inheritance.
 *
 * Polymorphism: Pokedex is the parent class and all the many classes (of pokemon) are child classes. There is the common method: pokemonEntry() which describes each pokemon.
 * For each child class, the same method is used, but has its own version of description as each pokemon is different.
 *
 * Inheritance: Each pokemon is a derived class from the pokedex.
 */

#pragma once
#include <string>
#include <iostream> 

using namespace std;

class Pokedex
{
public:
	Pokedex() {

	}
	virtual void pokemonEntry() {

	}
};

//derived classes from Pokedex, listing all 151 pokemon from Kanto region
class Bulbasaur : public Pokedex {
public:
	Bulbasaur() {

	}
		
	void pokemonEntry() {
		cout << "Bulbasaur can be seen napping in bright sunlight. There is a seed on its back. By soaking up the sun's rays, the seed grows progressively larger." << endl;
	}
};

class Ivysaur : public Pokedex {
public:
	Ivysaur() {

	}

	void pokemonEntry() {
		cout << "There is a bud on this Pokémon's back. To support its weight, Ivysaur's legs and trunk grow thick and strong. " << 
			"If it starts spending more time lying in the sunlight, it's a sign that the bud will bloom into a large flower soon." << endl;
	}
};

class Venusaur : public Pokedex {
public:
	Venusaur() {

	}

	void pokemonEntry() {
		cout << "There is a large flower on Venusaur's back. The flower is said to take on vivid colors if it gets plenty of nutrition and sunlight. " <<
			"The flower's aroma soothes the emotions of people." << endl;
	}
};

class Charmander : public Pokedex {
public:
	Charmander() {

	}

	void pokemonEntry() {
		cout << "The flame that burns at the tip of its tail is an indication of its emotions. The flame wavers when Charmander is enjoying itself. " 
			<<  "If the Pokémon becomes enraged, the flame burns fiercely." << endl;
	}
};

class Charmeleon : public Pokedex {
public:
	Charmeleon() {

	}

	void pokemonEntry() {
		cout << "Charmeleon mercilessly destroys its foes using its sharp claws. If it encounters a strong foe, it turns aggressive. "
			<< "In this excited state, the flame at the tip of its tail flares with a bluish white color." << endl;
	}
};

class Charizard : public Pokedex {
public:
	Charizard() {

	}

	void pokemonEntry() {
		cout << "Charizard flies around the sky in search of powerful opponents. It breathes fire of such great heat that it melts anything. "
			<< "However, it never turns its fiery breath on any opponent weaker than itself." << endl;
	}
};

class Squirtle : public Pokedex {
public:
	Squirtle() {

	}

	void pokemonEntry() {
		cout << "Squirtle's shell is not merely used for protection. " << 
			"The shell's rounded shape and the grooves on its surface help minimize resistance in water, enabling this Pokémon to swim at high speeds." << endl;
	}
};

class Wartortle : public Pokedex {
public:
	Wartortle() {

	}

	void pokemonEntry() {
		cout << "Its tail is large and covered with a rich, thick fur. The tail becomes increasingly deeper in color as Wartortle ages. "
			<< "The scratches on its shell are evidence of this Pokémon's toughness as a battler." << endl;
	}
};

class Blastoise : public Pokedex {
public:
	Blastoise() {

	}

	void pokemonEntry() {
		cout << "Blastoise has water spouts that protrude from its shell. The water spouts are very accurate. "
			<< "They can shoot bullets of water with enough accuracy to strike empty cans from a distance of over 160 feet." << endl;
	}
};

class Caterpie : public Pokedex {
public:
	Caterpie() {

	}

	void pokemonEntry() {
		cout << "Caterpie has a voracious appetite. It can devour leaves bigger than its body right before your eyes. From its antenna, this Pokémon releases a terrifically strong odor." << endl;
	}
};

class Metapod : public Pokedex {
public:
	Metapod() {

	}

	void pokemonEntry() {
		cout << "The shell covering this Pokémon's body is as hard as an iron slab. Metapod does not move very much. " <<
			"It stays still because it is preparing its soft innards for evolution inside the hard shell." << endl;
	}
};

class Butterfree : public Pokedex {
public:
	Butterfree() {

	}

	void pokemonEntry() {
		cout << "Butterfree has a superior ability to search for delicious honey from flowers. " <<
			"It can even search out, extract, and carry honey from flowers that are blooming over six miles from its nest." << endl;
	}
};

class Weedle : public Pokedex {
public:
	Weedle() {

	}

	void pokemonEntry() {
		cout << "Weedle has an extremely acute sense of smell. " <<
			"It is capable of distinguishing its favorite kinds of leaves from those it dislikes just by sniffing with its big red proboscis (nose)." << endl;
	}
};

class Kakuna : public Pokedex {
public:
	Kakuna() {

	}

	void pokemonEntry() {
		cout << "Kakuna remains virtually immobile as it clings to a tree. However, on the inside, it is extremely busy as it prepares for its coming evolution. "
			<< "This is evident from how hot the shell becomes to the touch." << endl;
	}
};

class Beedrill : public Pokedex {
public:
	Beedrill() {

	}

	void pokemonEntry() {
		cout << "Beedrill is extremely territorial. No one should ever approach its nest—this is for their own safety. If angered, they will attack in a furious swarm." << endl;
	}
};

class Pidgey : public Pokedex {
public:
	Pidgey() {

	}

	void pokemonEntry() {
		cout << "Pidgey has an extremely sharp sense of direction. It is capable of unerringly returning home to its nest, however far it may be removed from its familiar surroundings." << endl;
	}
};

class Pidgeotto : public Pokedex {
public:
	Pidgeotto() {

	}

	void pokemonEntry() {
		cout << "Pidgeotto claims a large area as its own territory. This Pokémon flies around, patrolling its living space. "
			<< "If its territory is violated, it shows no mercy in thoroughly punishing the foe with its sharp claws." << endl;
	}
};

class Pidgeot : public Pokedex {
public:
	Pidgeot() {

	}

	void pokemonEntry() {
		cout << "This Pokémon has a dazzling plumage of beautifully glossy feathers. "
			<< "Many Trainers are captivated by the striking beauty of the feathers on its head, compelling them to choose Pidgeot as their Pokémon." << endl;
	}
};

class Rattata : public Pokedex {
public:
	Rattata() {

	}

	void pokemonEntry() {
		cout << "Rattata is cautious in the extreme. " <<
			"Even while it is asleep, it constantly listens by moving its ears around. It is not picky about where it lives—it will make its nest anywhere." << endl;
	}
};

class Raticate : public Pokedex {
public:
	Raticate() {

	}

	void pokemonEntry() {
		cout << "Raticate's sturdy fangs grow steadily. To keep them ground down, it gnaws on rocks and logs. It may even chew on the walls of houses." << endl;
	}
};

class Spearow : public Pokedex {
public:
	Spearow() {

	}

	void pokemonEntry() {
		cout << "Spearow has a very loud cry that can be heard over half a mile away. " <<
			"If its high, keening cry is heard echoing all around, it is a sign that they are warning each other of danger." << endl;
	}
};

class Fearow : public Pokedex {
public:
	Fearow() {

	}

	void pokemonEntry() {
		cout << "Fearow is recognized by its long neck and elongated beak. They are conveniently shaped for catching prey in soil or water. " <<
			"It deftly moves its long and skinny beak to pluck prey." << endl;
	}
};

class Ekans : public Pokedex {
public:
	Ekans() {

	}

	void pokemonEntry() {
		cout << "Ekans curls itself up in a spiral while it rests. Assuming this position allows it to quickly respond to a threat from any direction with a glare from its upraised head." << endl;
	}
};

class Arbok : public Pokedex {
public:
	Arbok() {

	}

	void pokemonEntry() {
		cout << "This Pokémon is terrifically strong in order to constrict things with its body. It can even flatten steel oil drums. "
			<< "Once Arbok wraps its body around its foe, escaping its crunching embrace is impossible." << endl;
	}
};

class Pikachu : public Pokedex {
public:
	Pikachu() {

	}

	void pokemonEntry() {
		cout << "Whenever Pikachu comes across something new, it blasts it with a jolt of electricity. " <<
			"If you come across a blackened berry, it's evidence that this Pokémon mistook the intensity of its charge." << endl;
	}
};

class Raichu : public Pokedex {
public:
	Raichu() {

	}

	void pokemonEntry() {
		cout << "If the electrical sacs become excessively charged, Raichu plants its tail in the ground and discharges. Scorched patches of ground will be found near this Pokémon's nest." << endl;
	}
};

class Sandshrew : public Pokedex {
public:
	Sandshrew() {

	}

	void pokemonEntry() {
		cout << "Sandshrew's body is configured to absorb water without waste, enabling it to survive in an arid desert. This Pokémon curls up to protect itself from its enemies." << endl;
	}
};

class Sandslash : public Pokedex {
public:
	Sandslash() {

	}

	void pokemonEntry() {
		cout << "Sandslash's body is covered by tough spikes, which are hardened sections of its hide. "
			<< "Once a year, the old spikes fall out, to be replaced with new spikes that grow out from beneath the old ones." << endl;
	}
};

class Nidoran_Female : public Pokedex {
public:
	Nidoran_Female() {

	}

	void pokemonEntry() {
		cout << "Nidoran♀ has barbs that secrete a powerful poison. They are thought to have developed as protection for this small-bodied Pokémon. " <<
			"When enraged, it releases a horrible toxin from its horn." << endl;
	}
};

class Nidorina : public Pokedex {
public:
	Nidorina() {

	}

	void pokemonEntry() {
		cout << "When Nidorina are with their friends or family, they keep their barbs tucked away to prevent hurting each other. " <<
			"This Pokémon appears to become nervous if separated from the others." << endl;
	}
};

class Nidoqueen : public Pokedex {
public:
	Nidoqueen() {

	}

	void pokemonEntry() {
		cout << "Nidoqueen's body is encased in extremely hard scales. It is adept at sending foes flying with harsh tackles. " <<
			"This Pokémon is at its strongest when it is defending its young." << endl;
	}
};

class Nidoran_Male : public Pokedex {
public:
	Nidoran_Male() {

	}

	void pokemonEntry() {
		cout << "Nidoran♂ has developed muscles for moving its ears. Thanks to them, the ears can be freely moved in any direction. " << 
			"Even the slightest sound does not escape this Pokémon's notice." << endl;
	}
};

class Nidorino : public Pokedex {
public:
	Nidorino() {

	}

	void pokemonEntry() {
		cout << "Nidorino has a horn that is harder than a diamond. " <<
			"If it senses a hostile presence, all the barbs on its back bristle up at once, and it challenges the foe with all its might." << endl;
	}
};

class Nidoking : public Pokedex {
public:
	Nidoking() {

	}

	void pokemonEntry() {
		cout << "Nidoking's thick tail packs enormously destructive power. With one swing, it can topple a metal transmission tower. " <<
			"Once this Pokémon goes on a rampage, there is no stopping it." << endl;
	}
};

class Clefairy : public Pokedex {
public:
	Clefairy() {

	}

	void pokemonEntry() {
		cout << "On every night of a full moon, groups of this Pokémon come out to play. "
			<< "When dawn arrives, the tired Clefairy return to their quiet mountain retreats and go to sleep nestled up against each other." << endl;
	}
};

class Clefable : public Pokedex {
public:
	Clefable() {

	}

	void pokemonEntry() {
		cout << "Clefable moves by skipping lightly as if it were flying using its wings. Its bouncy step lets it even walk on water. " <<
			"It is known to take strolls on lakes on quiet, moonlit nights." << endl;
	}
};

class Vulpix : public Pokedex {
public:
	Vulpix() {

	}

	void pokemonEntry() {
		cout << "At the time of its birth, Vulpix has one white tail. The tail separates into six if this Pokémon receives plenty of love from its Trainer. " <<
			"The six tails become magnificently curled." << endl;
	}
};

class Ninetales : public Pokedex {
public:
	Ninetales() {

	}

	void pokemonEntry() {
		cout << "Ninetales casts a sinister light from its bright red eyes to gain total control over its foe's mind. This Pokémon is said to live for a thousand years." << endl;
	}
};

class Jigglypuff : public Pokedex {
public:
	Jigglypuff() {

	}

	void pokemonEntry() {
		cout << "Jigglypuff's vocal cords can freely adjust the wavelength of its voice. " <<
			"This Pokémon uses this ability to sing at precisely the right wavelength to make its foes most drowsy." << endl;
	}
};

class Wigglytuff : public Pokedex {
public:
	Wigglytuff() {

	}

	void pokemonEntry() {
		cout << "Wigglytuff has large, saucerlike eyes. The surfaces of its eyes are always covered with a thin layer of tears. " <<
			"If any dust gets in this Pokémon's eyes, it is quickly washed away." << endl;
	}
};

class Zubat : public Pokedex {
public:
	Zubat() {

	}

	void pokemonEntry() {
		cout << "Zubat remains quietly unmoving in a dark spot during the bright daylight hours. It does so because prolonged exposure to the sun causes its body to become slightly burned." << endl;
	}
};

class Golbat : public Pokedex {
public:
	Golbat() {

	}

	void pokemonEntry() {
		cout << "Golbat loves to drink the blood of living things. It is particularly active in the pitch black of night. This Pokémon flits around in the night skies, seeking fresh blood." << endl;
	}
};

class Oddish : public Pokedex {
public:
	Oddish() {

	}

	void pokemonEntry() {
		cout << "During the daytime, Oddish buries itself in soil to absorb nutrients from the ground using its entire body. The more fertile the soil, the glossier its leaves become." << endl;
	}
};

class Gloom : public Pokedex {
public:
	Gloom() {

	}

	void pokemonEntry() {
		cout << "Gloom releases a foul fragrance from the pistil of its flower. When faced with danger, the stench worsens. " <<
			"If this Pokémon is feeling calm and secure, it does not release its usual stinky aroma." << endl;
	}
};

class Vileplume : public Pokedex {
public:
	Vileplume() {

	}

	void pokemonEntry() {
		cout << "Vileplume's toxic pollen triggers atrocious allergy attacks. That's why it is advisable never to approach any attractive flowers in a jungle, however pretty they may be." << endl;
	}
};

class Paras : public Pokedex {
public:
	Paras() {

	}

	void pokemonEntry() {
		cout << "Paras has parasitic mushrooms growing on its back called tochukaso. They grow large by drawing nutrients from this Bug Pokémon host. " <<
			"They are highly valued as a medicine for extending life." << endl;
	}
};

class Parasect : public Pokedex {
public:
	Parasect() {

	}

	void pokemonEntry() {
		cout << "Parasect is known to infest large trees en masse and drain nutrients from the lower trunk and roots. When an infested tree dies, they move onto another tree all at once." << endl;
	}
};

class Venonat : public Pokedex {
public:
	Venonat() {

	}

	void pokemonEntry() {
		cout << "Venonat is said to have evolved with a coat of thin, stiff hair that covers its entire body for protection. " <<
			"It possesses large eyes that never fail to spot even minuscule prey." << endl;
	}
};

class Venomoth : public Pokedex {
public:
	Venomoth() {

	}

	void pokemonEntry() {
		cout << "Venomoth is nocturnal—it is a Pokémon that only becomes active at night. " <<
			"Its favorite prey are small insects that gather around streetlights, attracted by the light in the darkness." << endl;
	}
};

class Diglett : public Pokedex {
public:
	Diglett() {

	}

	void pokemonEntry() {
		cout << "Diglett are raised in most farms. The reason is simple— wherever this Pokémon burrows, the soil is left perfectly tilled for planting crops. "
			<< "This soil is made ideal for growing delicious vegetables." << endl;
	}
};

class Dugtrio : public Pokedex {
public:
	Dugtrio() {

	}

	void pokemonEntry() {
		cout << "Dugtrio are actually triplets that emerged from one body. As a result, each triplet thinks exactly like the other two triplets. They work cooperatively to burrow endlessly." << endl;
	}
};

class Meowth : public Pokedex {
public:
	Meowth() {

	}

	void pokemonEntry() {
		cout << "Meowth withdraws its sharp claws into its paws to slinkily sneak about without making any incriminating footsteps. " <<
			"For some reason, this Pokémon loves shiny coins that glitter with light." << endl;
	}
};

class Persian : public Pokedex {
public:
	Persian() {

	}

	void pokemonEntry() {
		cout << "Persian has six bold whiskers that give it a look of toughness. The whiskers sense air movements to determine what is in the Pokémon's surrounding vicinity. "
			<< "It becomes docile if grabbed by the whiskers." << endl;
	}
};

class Psyduck : public Pokedex {
public:
	Psyduck() {

	}

	void pokemonEntry() {
		cout << "Psyduck uses a mysterious power. When it does so, this Pokémon generates brain waves that are supposedly only seen in sleepers. " <<
			"This discovery spurred controversy among scholars." << endl;
	}
};

class Golduck : public Pokedex {
public:
	Golduck() {

	}

	void pokemonEntry() {
		cout << "The webbed flippers on its forelegs and hind legs and the streamlined body of Golduck give it frightening speed. " <<
			"This Pokémon is definitely much faster than even the most athletic swimmer." << endl;
	}
};

class Mankey : public Pokedex {
public:
	Mankey() {

	}

	void pokemonEntry() {
		cout << "When Mankey starts shaking and its nasal breathing turns rough, it's a sure sign that it is becoming angry. "
			<< "However, because it goes into a towering rage almost instantly, it is impossible for anyone to flee its wrath." << endl;
	}
};

class Primeape : public Pokedex {
public:
	Primeape() {

	}

	void pokemonEntry() {
		cout << "When Primeape becomes furious, its blood circulation is boosted. In turn, its muscles are made even stronger. However, it also becomes much less intelligent at the same time." << endl;
	}
};

class Growlithe : public Pokedex {
public:
	Growlithe() {

	}

	void pokemonEntry() {
		cout << "Growlithe has a superb sense of smell. Once it smells anything, this Pokémon won't forget the scent, no matter what. "
			<< "It uses its advanced olfactory sense to determine the emotions of other living things." << endl;
	}
};

class Arcanine : public Pokedex {
public:
	Arcanine() {

	}

	void pokemonEntry() {
		cout << "Arcanine is known for its high speed. It is said to be capable of running over 6,200 miles in a single day and night. "
			<< "The fire that blazes wildly within this Pokémon's body is its source of power." << endl;
	}
};

class Poliwag : public Pokedex {
public:
	Poliwag() {

	}

	void pokemonEntry() {
		cout << "Poliwag has a very thin skin. It is possible to see the Pokémon's spiral innards right through the skin. Despite its thinness, however, the skin is also very flexible. "
			<< "Even sharp fangs bounce right off it." << endl;
	}
};

class Poliwhirl : public Pokedex {
public:
	Poliwhirl() {

	}

	void pokemonEntry() {
		cout << "The surface of Poliwhirl's body is always wet and slick with a slimy fluid. " <<
			"Because of this slippery covering, it can easily slip and slide out of the clutches of any enemy in battle." << endl;
	}
};

class Poliwrath : public Pokedex {
public:
	Poliwrath() {

	}

	void pokemonEntry() {
		cout << "Poliwrath's highly developed, brawny muscles never grow fatigued, however much it exercises. "
			<< "It is so tirelessly strong, this Pokémon can swim back and forth across the ocean without effort." << endl;
	}
};

class Abra : public Pokedex {
public:
	Abra() {

	}

	void pokemonEntry() {
		cout << "Abra sleeps for eighteen hours a day. However, it can sense the presence of foes even while it is sleeping. In such a situation, this Pokémon immediately teleports to safety." << endl;
	}
};

class Kadabra : public Pokedex {
public:
	Kadabra() {

	}

	void pokemonEntry() {
		cout << "Kadabra emits a peculiar alpha wave if it develops a headache. Only those people with a particularly strong psyche can hope to become a Trainer of this Pokémon." << endl;
	}
};

class Alakazam : public Pokedex {
public:
	Alakazam() {

	}

	void pokemonEntry() {
		cout << "Alakazam's brain continually grows, making its head far too heavy to support with its neck. This Pokémon holds its head up using its psychokinetic power instead." << endl;
	}
};

class Machop : public Pokedex {
public:
	Machop() {

	}

	void pokemonEntry() {
		cout << "Machop's muscles are special—they never get sore no matter how much they are used in exercise. This Pokémon has sufficient power to hurl a hundred adult humans." << endl;
	}
};

class Machoke : public Pokedex {
public:
	Machoke() {

	}

	void pokemonEntry() {
		cout << "Machoke's thoroughly toned muscles possess the hardness of steel. This Pokémon has so much strength, it can easily hold aloft a sumo wrestler on just one finger." << endl;
	}
};

class Machamp : public Pokedex {
public:
	Machamp() {

	}

	void pokemonEntry() {
		cout << "Machamp has the power to hurl anything aside. However, trying to do any work requiring care and dexterity causes its arms to get tangled. " <<
			"This Pokémon tends to leap into action before it thinks." << endl;
	}
};

class Bellsprout : public Pokedex {
public:
	Bellsprout() {

	}

	void pokemonEntry() {
		cout << "Bellsprout's thin and flexible body lets it bend and sway to avoid any attack, however strong it may be. " <<
			"From its mouth, this Pokémon spits a corrosive fluid that melts even iron." << endl;
	}
};

class Weepinbell : public Pokedex {
public:
	Weepinbell() {

	}

	void pokemonEntry() {
		cout << "Weepinbell has a large hook on its rear end. At night, the Pokémon hooks on to a tree branch and goes to sleep. " <<
			"If it moves around in its sleep, it may wake up to find itself on the ground." << endl;
	}
};

class Victreebel : public Pokedex {
public:
	Victreebel() {

	}

	void pokemonEntry() {
		cout << "Victreebel has a long vine that extends from its head. This vine is waved and flicked about as if it were an animal to attract prey. "
			<< "When an unsuspecting prey draws near, this Pokémon swallows it whole." << endl;
	}
};

class Tentacool : public Pokedex {
public:
	Tentacool() {

	}

	void pokemonEntry() {
		cout << "Tentacool's body is largely composed of water. If it is removed from the sea, it dries up like parchment. If this Pokémon happens to become dehydrated, put it back into the sea." << endl;
	}
};

class Tentacruel : public Pokedex {
public:
	Tentacruel() {

	}

	void pokemonEntry() {
		cout << "Tentacruel has large red orbs on its head. The orbs glow before lashing the vicinity with a harsh ultrasonic blast. This Pokémon's outburst creates rough waves around it." << endl;
	}
};

class Geodude : public Pokedex {
public:
	Geodude() {

	}

	void pokemonEntry() {
		cout << "The longer a Geodude lives, the more its edges are chipped and worn away, making it more rounded in appearance. However, this Pokémon's heart will remain hard, craggy, and rough always." << endl;
	}
};

class Graveler : public Pokedex {
public:
	Graveler() {

	}

	void pokemonEntry() {
		cout << "Graveler grows by feeding on rocks. Apparently, it prefers to eat rocks that are covered in moss. This Pokémon eats its way through a ton of rocks on a daily basis." << endl;
	}
};

class Golem : public Pokedex {
public:
	Golem() {

	}

	void pokemonEntry() {
		cout << "Golem live up on mountains. If there is a large earthquake, these Pokémon will come rolling down off the mountains en masse to the foothills below." << endl;
	}
};

class Ponyta : public Pokedex {
public:
	Ponyta() {

	}

	void pokemonEntry() {
		cout << "Ponyta is very weak at birth. It can barely stand up. This Pokémon becomes stronger by stumbling and falling to keep up with its parent." << endl;
	}
};

class Rapidash : public Pokedex {
public:
	Rapidash() {

	}

	void pokemonEntry() {
		cout << "Rapidash usually can be seen casually cantering in the fields and plains. " <<
			"However, when this Pokémon turns serious, its fiery manes flare and blaze as it gallops its way up to 150 mph." << endl;
	}
};

class Slowpoke : public Pokedex {
public:
	Slowpoke() {

	}

	void pokemonEntry() {
		cout << "Slowpoke uses its tail to catch prey by dipping it in water at the side of a river. " <<
			"However, this Pokémon often forgets what it's doing and often spends entire days just loafing at water's edge." << endl;
	}
};

class Slowbro : public Pokedex {
public:
	Slowbro() {

	}

	void pokemonEntry() {
		cout << "Slowbro's tail has a Shellder firmly attached with a bite. As a result, the tail can't be used for fishing anymore. This causes Slowbro to grudgingly swim and catch prey instead." << endl;
	}
};

class Magnemite : public Pokedex {
public:
	Magnemite() {

	}

	void pokemonEntry() {
		cout << "Magnemite attaches itself to power lines to feed on electricity. If your house has a power outage, check your circuit breakers. "
			<< "You may find a large number of this Pokémon clinging to the breaker box." << endl;
	}
};

class Magneton : public Pokedex {
public:
	Magneton() {

	}

	void pokemonEntry() {
		cout << "Magneton emits a powerful magnetic force that is fatal to mechanical devices. As a result, large cities sound sirens to warn citizens of large-scale outbreaks of this Pokémon." << endl;
	}
};

class Farfetch : public Pokedex {
public:
	Farfetch() {

	}

	void pokemonEntry() {
		cout << "Farfetch'd is always seen with a stalk from a plant of some sort. Apparently, there are good stalks and bad stalks. This Pokémon has been known to fight with others over stalks." << endl;
	}
};

class Doduo : public Pokedex {
public:
	Doduo() {

	}

	void pokemonEntry() {
		cout << "Doduo's two heads never sleep at the same time. Its two heads take turns sleeping, so one head can always keep watch for enemies while the other one sleeps." << endl;
	}
};

class Dodrio : public Pokedex {
public:
	Dodrio() {

	}

	void pokemonEntry() {
		cout << "Watch out if Dodrio's three heads are looking in three separate directions. It's a sure sign that it is on its guard. " <<
			"Don't go near this Pokémon if it's being wary—it may decide to peck you." << endl;
	}
};

class Seel : public Pokedex {
public:
	Seel() {

	}

	void pokemonEntry() {
		cout << "Seel hunts for prey in the frigid sea underneath sheets of ice. When it needs to breathe, it punches a hole through the ice with the sharply protruding section of its head." << endl;
	}
};

class Dewgong : public Pokedex {
public:
	Dewgong() {

	}

	void pokemonEntry() {
		cout << "Dewgong loves to snooze on bitterly cold ice. The sight of this Pokémon sleeping on a glacier was mistakenly thought to be a mermaid by a mariner long ago." << endl;
	}
};

class Grimer : public Pokedex {
public:
	Grimer() {

	}

	void pokemonEntry() {
		cout << "Grimer's sludgy and rubbery body can be forced through any opening, however small it may be. This Pokémon enters sewer pipes to drink filthy wastewater." << endl;
	}
};

class Muk : public Pokedex {
public:
	Muk() {

	}

	void pokemonEntry() {
		cout << "From Muk's body seeps a foul fluid that gives off a nose-bendingly horrible stench. Just one drop of this Pokémon's body fluid can turn a pool stagnant and rancid." << endl;
	}
};

class Shellder : public Pokedex {
public:
	Shellder() {

	}

	void pokemonEntry() {
		cout << "At night, this Pokémon uses its broad tongue to burrow a hole in the seafloor sand and then sleep in it. " <<
			"While it is sleeping, Shellder closes its shell, but leaves its tongue hanging out." << endl;
	}
};

class Cloyster : public Pokedex {
public:
	Cloyster() {

	}

	void pokemonEntry() {
		cout << "Cloyster is capable of swimming in the sea. It does so by swallowing water, then jetting it out toward the rear. This Pokémon shoots spikes from its shell using the same system." << endl;
	}
};

class Gastly : public Pokedex {
public:
	Gastly() {

	}

	void pokemonEntry() {
		cout << "Gastly is largely composed of gaseous matter. When exposed to a strong wind, the gaseous body quickly dwindles away. "
			<< "Groups of this Pokémon cluster under the eaves of houses to escape the ravages of wind." << endl;
	}
};

class Haunter : public Pokedex {
public:
	Haunter() {

	}

	void pokemonEntry() {
		cout << "Haunter is a dangerous Pokémon. If one beckons you while floating in darkness, you must never approach it. " <<
			"This Pokémon will try to lick you with its tongue and steal your life away." << endl;
	}
};

class Gengar : public Pokedex {
public:
	Gengar() {

	}

	void pokemonEntry() {
		cout << "Sometimes, on a dark night, your shadow thrown by a streetlight will suddenly and startlingly overtake you. It is actually a Gengar running past you, pretending to be your shadow." << endl;
	}
};

class Onix : public Pokedex {
public:
	Onix() {

	}

	void pokemonEntry() {
		cout << "Onix has a magnet in its brain. It acts as a compass so that this Pokémon does not lose direction while it is tunneling. " <<
			"As it grows older, its body becomes increasingly rounder and smoother." << endl;
	}
};

class Drowzee : public Pokedex {
public:
	Drowzee() {

	}

	void pokemonEntry() {
		cout << "If your nose becomes itchy while you are sleeping, it's a sure sign that one of these Pokémon is standing above your pillow and trying to eat your dream through your nostrils." << endl;
	}
};

class Hypno : public Pokedex {
public:
	Hypno() {

	}

	void pokemonEntry() {
		cout << "Hypno holds a pendulum in its hand. The arcing movement and glitter of the pendulum lull the foe into a deep state of hypnosis. " <<
			"While this Pokémon searches for prey, it polishes the pendulum." << endl;
	}
};

class Krabby : public Pokedex {
public:
	Krabby() {

	}

	void pokemonEntry() {
		cout << "Krabby live on beaches, burrowed inside holes dug into the sand. " <<
			"On sandy beaches with little in the way of food, these Pokémon can be seen squabbling with each other over territory." << endl;
	}
};

class Kingler : public Pokedex {
public:
	Kingler() {

	}

	void pokemonEntry() {
		cout << "Kingler has an enormous, oversized claw. It waves this huge claw in the air to communicate with others. However, because the claw is so heavy, the Pokémon quickly tires." << endl;
	}
};

class Voltorb : public Pokedex {
public:
	Voltorb() {

	}

	void pokemonEntry() {
		cout << "Voltorb was first sighted at a company that manufactures Poké Balls. " <<
			"The link between that sighting and the fact that this Pokémon looks very similar to a Poké Ball remains a mystery." << endl;
	}
};

class Electrode : public Pokedex {
public:
	Electrode() {

	}

	void pokemonEntry() {
		cout << "Electrode eats electricity in the atmosphere. On days when lightning strikes, you can see this Pokémon exploding all over the place from eating too much electricity." << endl;
	}
};

class Exeggcute : public Pokedex {
public:
	Exeggcute() {

	}

	void pokemonEntry() {
		cout << "This Pokémon consists of six eggs that form a closely knit cluster. The six eggs attract each other and spin around. " <<
			"When cracks increasingly appear on the eggs, Exeggcute is close to evolution." << endl;
	}
};

class Exeggutor : public Pokedex {
public:
	Exeggutor() {

	}

	void pokemonEntry() {
		cout << "Exeggutor originally came from the tropics. Its heads steadily grow larger from exposure to strong sunlight. " <<
			"It is said that when the heads fall off, they group together to form Exeggcute." << endl;
	}
};

class Cubone : public Pokedex {
public:
	Cubone() {

	}

	void pokemonEntry() {
		cout << "Cubone pines for the mother it will never see again. Seeing a likeness of its mother in the full moon, it cries. " <<
			"The stains on the skull the Pokémon wears are made by the tears it sheds." << endl;
	}
};

class Marowak : public Pokedex {
public:
	Marowak() {

	}

	void pokemonEntry() {
		cout << "Marowak is the evolved form of a Cubone that has overcome its sadness at the loss of its mother and grown tough. " <<
			"This Pokémon's tempered and hardened spirit is not easily broken." << endl;
	}
};

class Hitmonlee : public Pokedex {
public:
	Hitmonlee() {

	}

	void pokemonEntry() {
		cout << "Hitmonlee's legs freely contract and stretch. Using these springlike legs, it bowls over foes with devastating kicks. "
			<< "After battle, it rubs down its legs and loosens the muscles to overcome fatigue." << endl;
	}
};

class Hitmonchan : public Pokedex {
public:
	Hitmonchan() {

	}

	void pokemonEntry() {
		cout << "Hitmonchan is said to possess the spirit of a boxer who had been working toward a world championship. " <<
			"This Pokémon has an indomitable spirit and will never give up in the face of adversity." << endl;
	}
};

class Lickitung : public Pokedex {
public:
	Lickitung() {

	}

	void pokemonEntry() {
		cout << "Whenever Lickitung comes across something new, it will unfailingly give it a lick. It does so because it memorizes things by texture and by taste. " <<
			"It is somewhat put off by sour things." << endl;
	}
};

class Koffing : public Pokedex {
public:
	Koffing() {

	}

	void pokemonEntry() {
		cout << "If Koffing becomes agitated, it raises the toxicity of its internal gases and jets them out from all over its body. " <<
			"This Pokémon may also overinflate its round body, then explode." << endl;
	}
};

class Weezing : public Pokedex {
public:
	Weezing() {

	}

	void pokemonEntry() {
		cout << "Weezing loves the gases given off by rotted kitchen garbage. This Pokémon will find a dirty, unkempt house and make it its home. "
			<< "At night, when the people in the house are asleep, it will go through the trash." << endl;
	}
};

class Rhyhorn : public Pokedex {
public:
	Rhyhorn() {

	}

	void pokemonEntry() {
		cout << "Rhyhorn runs in a straight line, smashing everything in its path. It is not bothered even if it rushes headlong into a block of steel. "
			<< "This Pokémon may feel some pain from the collision the next day, however." << endl;
	}
};

class Rhydon : public Pokedex {
public:
	Rhydon() {

	}

	void pokemonEntry() {
		cout << "Rhydon's horn can crush even uncut diamonds. One sweeping blow of its tail can topple a building. " <<
			"This Pokémon's hide is extremely tough. Even direct cannon hits don't leave a scratch." << endl;
	}
};

class Chansey : public Pokedex {
public:
	Chansey() {

	}

	void pokemonEntry() {
		cout << "Chansey lays nutritionally excellent eggs on an everyday basis. The eggs are so delicious, they are easily and eagerly devoured by even those people who have lost their appetite." << endl;
	}
};

class Tangela : public Pokedex {
public:
	Tangela() {

	}

	void pokemonEntry() {
		cout << "Tangela's vines snap off easily if they are grabbed. This happens without pain, allowing it to make a quick getaway. " <<
			"The lost vines are replaced by newly grown vines the very next day." << endl;
	}
};

class Kangaskhan : public Pokedex {
public:
	Kangaskhan() {

	}

	void pokemonEntry() {
		cout << "If you come across a young Kangaskhan playing by itself, you must never disturb it or attempt to catch it. "
			<< "The baby Pokémon's parent is sure to be in the area, and it will become violently enraged at you." << endl;
	}
};

class Horsea : public Pokedex {
public:
	Horsea() {

	}

	void pokemonEntry() {
		cout << "Horsea eats small insects and moss off of rocks. " <<
			"If the ocean current turns fast, this Pokémon anchors itself by wrapping its tail around rocks or coral to prevent being washed away." << endl;
	}
};

class Seadra : public Pokedex {
public:
	Seadra() {

	}

	void pokemonEntry() {
		cout << "Seadra sleeps after wriggling itself between the branches of coral. Those trying to harvest coral are occasionally stung by this Pokémon's poison barbs if they fail to notice it." << endl;
	}
};

class Goldeen : public Pokedex {
public:
	Goldeen() {

	}

	void pokemonEntry() {
		cout << "Goldeen is a very beautiful Pokémon with fins that billow elegantly in water. However, don't let your guard down around this Pokémon—it could ram you powerfully with its horn." << endl;
	}
};

class Seaking : public Pokedex {
public:
	Seaking() {

	}

	void pokemonEntry() {
		cout << "In the autumn, Seaking males can be seen performing courtship dances in riverbeds to woo females. During this season, this Pokémon's body coloration is at its most beautiful." << endl;
	}
};

class Staryu : public Pokedex {
public:
	Staryu() {

	}

	void pokemonEntry() {
		cout << "Staryu's center section has an organ called the core that shines bright red. " <<
			"If you go to a beach toward the end of summer, the glowing cores of these Pokémon look like the stars in the sky." << endl;
	}
};

class Starmie : public Pokedex {
public:
	Starmie() {

	}

	void pokemonEntry() {
		cout << "Starmie's center section—the core—glows brightly in seven colors. Because of its luminous nature, this Pokémon has been given the nickname “the gem of the sea.\"" << endl;
	}
};

class Mr_Mime : public Pokedex {
public:
	Mr_Mime() {

	}

	void pokemonEntry() {
		cout << "Mr. Mime is a master of pantomime. Its gestures and motions convince watchers that something unseeable actually exists. "
			<< "Once the watchers are convinced, the unseeable thing exists as if it were real." << endl;
	}
};

class Scyther : public Pokedex {
public:
	Scyther() {

	}

	void pokemonEntry() {
		cout << "Scyther is blindingly fast. Its blazing speed enhances the effectiveness of the twin scythes on its forearms. "
			<< "This Pokémon's scythes are so effective, they can slice through thick logs in one wicked stroke." << endl;
	}
};

class Jynx : public Pokedex {
public:
	Jynx() {

	}

	void pokemonEntry() {
		cout << "Jynx walks rhythmically, swaying and shaking its hips as if it were dancing. "
			<< "Its motions are so bouncingly alluring, people seeing it are compelled to shake their hips without giving any thought to what they are doing." << endl;
	}
};

class Electabuzz : public Pokedex {
public:
	Electabuzz() {

	}

	void pokemonEntry() {
		cout << "When a storm arrives, gangs of this Pokémon compete with each other to scale heights that are likely to be stricken by lightning bolts. " <<
			"Some towns use Electabuzz in place of lightning rods." << endl;
	}
};

class Magmar : public Pokedex {
public:
	Magmar() {

	}

	void pokemonEntry() {
		cout << "In battle, Magmar blows out intensely hot flames from all over its body to intimidate its opponent. " <<
			"This Pokémon's fiery bursts create heat waves that ignite grass and trees in its surroundings." << endl;
	}
};

class Pinsir : public Pokedex {
public:
	Pinsir() {

	}

	void pokemonEntry() {
		cout << "Pinsir is astoundingly strong. It can grip a foe weighing twice its weight in its horns and easily lift it. This Pokémon's movements turn sluggish in cold places." << endl;
	}
};

class Tauros : public Pokedex {
public:
	Tauros() {

	}

	void pokemonEntry() {
		cout << "This Pokémon is not satisfied unless it is rampaging at all times. If there is no opponent for Tauros to battle, it will charge at thick trees and knock them down to calm itself." << endl;
	}
};

class Magikarp : public Pokedex {
public:
	Magikarp() {

	}

	void pokemonEntry() {
		cout << "Magikarp is a pathetic excuse for a Pokémon that is only capable of flopping and splashing. This behavior prompted scientists to undertake research into it." << endl;
	}
};

class Gyarados : public Pokedex {
public:
	Gyarados() {

	}

	void pokemonEntry() {
		cout << "When Magikarp evolves into Gyarados, its brain cells undergo a structural transformation. It is said that this transformation is to blame for this Pokémon's wildly violent nature." << endl;
	}
};

class Lapras : public Pokedex {
public:
	Lapras() {

	}

	void pokemonEntry() {
		cout << "People have driven Lapras almost to the point of extinction. In the evenings, this Pokémon is said to sing plaintively as it seeks what few others of its kind still remain." << endl;
	}
};

class Ditto : public Pokedex {
public:
	Ditto() {

	}

	void pokemonEntry() {
		cout << "Ditto rearranges its cell structure to transform itself into other shapes. "
			<< "However, if it tries to transform itself into something by relying on its memory, this Pokémon manages to get details wrong." << endl;
	}
};

class Eevee : public Pokedex {
public:
	Eevee() {

	}

	void pokemonEntry() {
		cout << "Eevee has an unstable genetic makeup that suddenly mutates due to the environment in which it lives. Radiation from various stones causes this Pokémon to evolve." << endl;
	}
};

class Vaporeon : public Pokedex {
public:
	Vaporeon() {

	}

	void pokemonEntry() {
		cout << "Vaporeon underwent a spontaneous mutation and grew fins and gills that allow it to live underwater. This Pokémon has the ability to freely control water." << endl;
	}
};

class Jolteon : public Pokedex {
public:
	Jolteon() {

	}

	void pokemonEntry() {
		cout << "Jolteon's cells generate a low level of electricity. This power is amplified by the static electricity of its fur, enabling the Pokémon to drop thunderbolts. "
			<< "The bristling fur is made of electrically charged needles." << endl;
	}
};

class Flareon : public Pokedex {
public:
	Flareon() {

	}

	void pokemonEntry() {
		cout << "Flareon's fluffy fur has a functional purpose—it releases heat into the air so that its body does not get excessively hot. "
			<< "This Pokémon's body temperature can rise to a maximum of 1,650 degrees Fahrenheit." << endl;
	}
};

class Porygon : public Pokedex {
public:
	Porygon() {

	}

	void pokemonEntry() {
		cout << "Porygon is capable of reverting itself entirely back to program data and entering cyberspace. This Pokémon is copy protected so it cannot be duplicated by copying." << endl;
	}
};

class Omanyte : public Pokedex {
public:
	Omanyte() {

	}

	void pokemonEntry() {
		cout << "Omanyte is one of the ancient and long-since-extinct Pokémon that have been regenerated from fossils by people. " <<
			"If attacked by an enemy, it withdraws itself inside its hard shell." << endl;
	}
};

class Omastar : public Pokedex {
public:
	Omastar() {

	}

	void pokemonEntry() {
		cout << "Omastar uses its tentacles to capture its prey. " <<
			"It is believed to have become extinct because its shell grew too large and heavy, causing its movements to become too slow and ponderous." << endl;
	}
};

class Kabuto : public Pokedex {
public:
	Kabuto() {

	}

	void pokemonEntry() {
		cout << "Kabuto is a Pokémon that has been regenerated from a fossil. However, in extremely rare cases, living examples have been discovered. " <<
			"The Pokémon has not changed at all for 300 million years." << endl;
	}
};

class Kabutops : public Pokedex {
public:
	Kabutops() {

	}

	void pokemonEntry() {
		cout << "Kabutops swam underwater to hunt for its prey in ancient times. "
			<< "The Pokémon was apparently evolving from being a water dweller to living on land as evident from the beginnings of change in its gills and legs." << endl;
	}
};

class Aerodactyl : public Pokedex {
public:
	Aerodactyl() {

	}

	void pokemonEntry() {
		cout << "Aerodactyl is a Pokémon from the age of dinosaurs. It was regenerated from genetic material extracted from amber. " <<
			"It is imagined to have been the king of the skies in ancient times." << endl;
	}
};

class Snorlax : public Pokedex {
public:
	Snorlax() {

	}

	void pokemonEntry() {
		cout << "Snorlax's typical day consists of nothing more than eating and sleeping. It is such a docile Pokémon that there are children who use its expansive belly as a place to play." << endl;
	}
};

class Articuno : public Pokedex {
public:
	Articuno() {

	}

	void pokemonEntry() {
		cout << "Articuno is a legendary bird Pokémon that can control ice. The flapping of its wings chills the air. As a result, it is said that when this Pokémon flies, snow will fall." << endl;
	}
};

class Zapdos : public Pokedex {
public:
	Zapdos() {

	}

	void pokemonEntry() {
		cout << "Zapdos is a legendary bird Pokémon that has the ability to control electricity. It usually lives in thunderclouds. The Pokémon gains power if it is stricken by lightning bolts." << endl;
	}
};

class Moltres : public Pokedex {
public:
	Moltres() {

	}

	void pokemonEntry() {
		cout << "Moltres is a legendary bird Pokémon that has the ability to control fire. " <<
			"If this Pokémon is injured, it is said to dip its body in the molten magma of a volcano to burn and heal itself." << endl;
	}
};

class Dratini : public Pokedex {
public:
	Dratini() {

	}

	void pokemonEntry() {
		cout << "Dratini continually molts and sloughs off its old skin. It does so because the life energy within its body steadily builds to reach uncontrollable levels." << endl;
	}
};

class Dragonair : public Pokedex {
public:
	Dragonair() {

	}

	void pokemonEntry() {
		cout << "Dragonair stores an enormous amount of energy inside its body. It is said to alter weather conditions in its vicinity by discharging energy from the crystals on its neck and tail." << endl;
	}
};

class Dragonite : public Pokedex {
public:
	Dragonite() {

	}

	void pokemonEntry() {
		cout << "Dragonite is capable of circling the globe in just 16 hours. It is a kindhearted Pokémon that leads lost and foundering ships in a storm to the safety of land." << endl;
	}
};

class Mewtwo : public Pokedex {
public:
	Mewtwo() {

	}

	void pokemonEntry() {
		cout << "Mewtwo is a Pokémon that was created by genetic manipulation. "
			<< "However, even though the scientific power of humans created this Pokémon's body, they failed to endow Mewtwo with a compassionate heart." << endl;
	}
};

class Mew : public Pokedex {
public:
	Mew() {

	}

	void pokemonEntry() {
		cout << "Mew is said to possess the genetic composition of all Pokémon. It is capable of making itself invisible at will, so it entirely avoids notice even if it approaches people." << endl;
	}
};

/*
 * This is a small example of abstraction.
 *
 * Abstraction: There is the abstraction of importing files. We know it imports data to use arrays, but we don't know the gnitty gritty of how it all works.
 * There is also abstraction with this class. In this class, you can see all the instances of objects as well as the code needed to display the information. However,
 * this data will not be visible to the main function. The user will simply run it and all the data is listed based on what they want to see (trainers, leaders, people, or all).
 */

#pragma once
#include "Person.h"
#include "Pokedex.h"

class program
{
private:
	//variables I need to use in this class
	Trainer kat;
	Trainer michael;
	Person ellie;
	GymLeader brock;
	GymLeader misty;
	GymLeader surge;
	GymLeader erika;
	GymLeader koga;
	GymLeader sabrina;
	GymLeader blaine;
	GymLeader giovanni;

	Eevee eevee;
	Charizard charizard;
	Arcanine arcanine;
	Dratini dratini;
	Pikachu pikachu;
	Squirtle squirtle;
	Persian persian;
	Geodude geodude;
	Onix onix;
	Staryu staryu;
	Starmie starmie;
	Voltorb voltorb;
	Raichu raichu;
	Victreebel victreebel;
	Tangela tangela;
	Vileplume vileplume;
	Koffing koffing;
	Muk muk;
	Kadabra kadabra;
	Mr_Mime mr_Mime;
	Venomoth venomoth;
	Alakazam alakazam;
	Growlithe growlithe;
	Ponyta ponyta;
	Rapidash rapidash;
	Rhyhorn rhyhorn;
	Kangaskhan kangaskhan;
public:
	program() {
		//these are the pokemon for one person, stored in a vector
		vector<string>pokemon;
		pokemon.push_back("Eevee");
		pokemon.push_back("Charizard");
		pokemon.push_back("Arcanine");
		pokemon.push_back("Dratini");

		vector<string> badges;
		badges.push_back("Boulder Badge");
		badges.push_back("Cascade Badge");
		badges.push_back("Rainbow Badge");

		Trainer Kat(3, badges);
		Kat.setName("Kat");
		Kat.setPokemon(pokemon);
		kat = Kat;

		pokemon.clear();
		pokemon.push_back("Pikachu");
		pokemon.push_back("Squirtle");

		badges.clear();

		Trainer Michael(0, badges);
		Michael.setName("Michael");
		Michael.setPokemon(pokemon);
		michael = Michael;

		pokemon.clear();
		pokemon.push_back("Persian");

		Person Ellie("Ellie", pokemon);
		ellie = Ellie;

		pokemon.clear();
		pokemon.push_back("Geodude");
		pokemon.push_back("Onix");

		GymLeader Brock("Boulder Badge");
		Brock.setName("Brock");
		Brock.setPokemon(pokemon);
		brock = Brock;

		pokemon.clear();
		pokemon.push_back("Staryu");
		pokemon.push_back("Starmie");

		GymLeader Misty("Cascade Badge");
		Misty.setName("Misty");
		Misty.setPokemon(pokemon);
		misty = Misty;

		pokemon.clear();
		pokemon.push_back("Voltorb");
		pokemon.push_back("Pikachu");
		pokemon.push_back("Raichu");

		GymLeader Surge("Thunder Badge");
		Surge.setName("Lt. Surge");
		Surge.setPokemon(pokemon);
		surge = Surge;

		pokemon.clear();
		pokemon.push_back("Victreebel");
		pokemon.push_back("Tangela");
		pokemon.push_back("Vileplume");

		GymLeader Erika("Rainbow Badge");
		Erika.setName("Erika");
		Erika.setPokemon(pokemon);
		erika = Erika;

		pokemon.clear();
		pokemon.push_back("Koffing");
		pokemon.push_back("Muk");

		GymLeader Koga("Soul Badge");
		Koga.setName("Koga");
		Koga.setPokemon(pokemon);
		koga = Koga;

		pokemon.clear();
		pokemon.push_back("Kadabra");
		pokemon.push_back("Mr. Mime");
		pokemon.push_back("Venomoth");
		pokemon.push_back("Alakazam");

		GymLeader Sabrina("Marsh Badge");
		Sabrina.setName("Sabrina");
		Sabrina.setPokemon(pokemon);
		sabrina = Sabrina;

		pokemon.clear();
		pokemon.push_back("Growlithe");
		pokemon.push_back("Ponyta");
		pokemon.push_back("Rapidash");
		pokemon.push_back("Arcanine");


		GymLeader Blaine("Volcano Badge");
		Blaine.setName("Blaine");
		Blaine.setPokemon(pokemon);
		blaine = Blaine;

		pokemon.clear();
		pokemon.push_back("Onix");
		pokemon.push_back("Rhyhorn");
		pokemon.push_back("Kangaskhan");

		GymLeader Giovanni("Earth Badge");
		Giovanni.setName("Giovanni");
		Giovanni.setPokemon(pokemon);
		giovanni = Giovanni;
	};

	void runPeople() {
		displayPeople(ellie);
		cout << endl;
		persian.pokemonEntry();
		cout << endl;
		cout << endl;
	}

	void runTrainers() {
		displayTrainers(kat);
		cout << endl;
		eevee.pokemonEntry();
		charizard.pokemonEntry();
		arcanine.pokemonEntry();
		dratini.pokemonEntry();

		cout << endl;
		cout << endl;

		displayTrainers(michael);
		cout << endl;
		pikachu.pokemonEntry();
		squirtle.pokemonEntry();

		cout << endl;
		cout << endl;
	}

	void runGymLeaders() {
		displayGymLeaders(brock);
		cout << endl;
		geodude.pokemonEntry();
		onix.pokemonEntry();

		cout << endl;
		cout << endl;

		displayGymLeaders(misty);
		cout << endl;
		staryu.pokemonEntry();
		starmie.pokemonEntry();

		cout << endl;
		cout << endl;

		displayGymLeaders(surge);
		cout << endl;
		voltorb.pokemonEntry();
		pikachu.pokemonEntry();
		raichu.pokemonEntry();

		cout << endl;
		cout << endl;

		displayGymLeaders(erika);
		cout << endl;
		victreebel.pokemonEntry();
		tangela.pokemonEntry();
		vileplume.pokemonEntry();

		cout << endl;
		cout << endl;

		displayGymLeaders(koga);
		cout << endl;
		koffing.pokemonEntry();
		muk.pokemonEntry();

		cout << endl;
		cout << endl;

		displayGymLeaders(sabrina);
		cout << endl;
		kadabra.pokemonEntry();
		mr_Mime.pokemonEntry();
		venomoth.pokemonEntry();
		alakazam.pokemonEntry();

		cout << endl;
		cout << endl;

		displayGymLeaders(blaine);
		cout << endl;
		growlithe.pokemonEntry();
		ponyta.pokemonEntry();
		rapidash.pokemonEntry();
		arcanine.pokemonEntry();

		cout << endl;
		cout << endl;

		displayGymLeaders(giovanni);
		cout << endl;
		rhyhorn.pokemonEntry();
		kangaskhan.pokemonEntry();
	}

	void runAll() {
		runPeople();
		runTrainers();
		runGymLeaders();
	}

	void displayTrainers(Trainer trainer) {
		cout << "Trainer's Name: " << trainer.getName() << endl;
		cout << "Trainer's Pokemon: ";
		readVector(trainer.getPokemon());
		cout << endl;
		cout << "Num of Badges: " << trainer.getNumOfBadges() << endl;
		cout << "Trainer's Badges: ";
		readVector(trainer.getBadges());
		cout << endl;
	}

	void displayGymLeaders(GymLeader gymLeader) {
		cout << "Gym Leader's Name: " << gymLeader.getName() << endl;
		cout << "Gym Leader's Pokemon: ";
		readVector(gymLeader.getPokemon());
		cout << endl;
		cout << "Type of Gym Badge: " << gymLeader.getBadge() << endl;
	}

	void displayPeople(Person person) {
		cout << "Person's Name: " << person.getName() << endl;
		cout << "Person's Pokemon: ";
		readVector(person.getPokemon());
		cout << endl;
	}

	//iterates through a vector and prints it on the console
	void readVector(vector<string> temp) {
		for (int i = 0; i < temp.size(); i++) {
			cout << temp.at(i) << " ";
		}
	}
};

